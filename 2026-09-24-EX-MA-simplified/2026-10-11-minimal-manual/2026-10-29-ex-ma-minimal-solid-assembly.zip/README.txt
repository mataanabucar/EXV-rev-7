EX-MA manual excavator - MINIMAL design (no PVC conduit), assembly as solid bodies
==================================================================================

2026-10-29-ex-ma-minimal-solid-assembly.step
    STEP AP214, millimetres, Z up. Floor bottom (control box and sandbox) on Z = 0, footprint
    centred on X = 0 / Y = 0. X runs from the box rear toward the sandbox, Y to the operator's left.
parts/        the nine EX-MA parts on their own in the build frame, and the elbow support with its
              base plate cut off (print frame).
checks.json   the numbers below, machine readable.

This is the build in 2026-10-11-ex-ma-minimal-manual.pdf: 7/16in OSB, 5/8in particle-board sandbox
floor (24 x 24in, uncut), no shim, two OSB spacer frames and four 8-32 through-rods instead of the
2in PVC conduit, compact control box (8-7/16 x 15 x 6-1/8in) with the lever hubs and 145 mm slew spool as already
printed. Wood pieces carry the manual's W numbers.

Structure: one component per part, each one solid body, grouped as
  Arm: 10
  Control box: 20
  Hardware/5-16 rod, nuts, washers: 13
  Hardware/8-32 pins and jam nuts: 17
  Hardware/8-32 through-rods: 12
  Hardware/M3 screws, nuts, washers: 129
  Hardware/wood screws: 139
  Pedestal: 16
  Ropes, PTFE tubes, crimps: 27
  Sandbox: 5
  Slewing ring balls: 57
  Turret and slewing ring: 3
Components: 448.

Every body is a B-rep solid (holes are cylinders, faces are planes / cylinders / cones / spheres).
Fasteners have plain shanks at the nominal diameter (no modelled threads). Ropes and PTFE tubes
are swept along their modelled paths at the built pose.

EX-MA parts (deviation = surface distance to the print STL):
  boom-half-left: converted from the print STL; valid True, 2055 faces, deviation p99 0.005 mm / max 2.529 mm
  boom-half-right: converted from the print STL; valid True, 2429 faces, deviation p99 0.006 mm / max 0.541 mm
  stick-half-left: converted from the print STL; valid True, 1244 faces, deviation p99 1.15 mm / max 3.662 mm
  stick-half-right: converted from the print STL; valid True, 1237 faces, deviation p99 0.476 mm / max 4.158 mm
  bucket: converted from the print STL; valid True, 560 faces, deviation p99 0.053 mm / max 0.071 mm
  tower: converted from the print STL; valid True, 687 faces, deviation p99 0.015 mm / max 0.049 mm
  bucket-ear-left: 2026-09-29-bucket-ear-left-cad.step; valid True, 24 faces, deviation p99 0.012 mm / max 0.012 mm
  bucket-ear-right: 2026-09-29-bucket-ear-right-cad.step; valid True, 24 faces, deviation p99 0.012 mm / max 0.012 mm
  base: 2026-09-29-base.step; valid True, 189 faces, deviation p99 0.087 mm / max 0.168 mm

Assembly read back: 448 solids for 448 components, 0 invalid, size 839.0 x 610.0 x 409.3 mm (33.03 x 24.02 x 16.11 in)

Notes:
- the elbow support's post sits on the sandbox floor; its single #6 x 1-1/4in screw comes up
  through the floor (manual Stage 4).
- the 7/16in OSB shelf rests on its cleats about 0.9 mm lower than the 12 mm shelf of the design,
  so the PEX bushing sits that much lower (it still guides the tube; nothing else moves).
- the drum key screws of the stick drum overlap as in the design (manual Open item 1).
- the seven #6 x 3/4in screws through the spool riser (3) and the sleeve posts (4) are 2.3 mm (3/32in)
  longer than printed flange + 7/16in OSB box floor: their tips show under the box floor. Use
  #6 x 5/8in there, or file the tips flush.
- arm halves: the converter rebuilds every build modification as CAD booleans. Three halves did not
  read back from STEP as one valid solid at first and were repaired with
  2026-10-29-repair-step-roundtrip.py: stick-half-right used as written (it only missed the 1 mm3
  volume check), stick-half-left with four faces rebuilt as NURBS, boom-half-left with two small
  blend faces (about 2 mm2 together) replaced by filled patches.
- stick halves differ from the print STL by up to about 4 mm at internal spots near the split face
  (stop bulkhead clipped to one convex hull, solid nose as one cylinder); outside surfaces match.

Rebuild: MINIMAL_SRC=$(python 2026-10-11-make-minimal-source.py WORK) \
         python 2026-10-11-minimal-manual/source/2026-10-29-minimal-solid-assembly.py WORK
         (after converting the parts into WORK/parts with Source/2026-09-28-mesh-to-brep.py and
         2026-09-28-arm-halves-cad.py, and repairing failed halves with
         2026-10-29-repair-step-roundtrip.py; CadQuery 2.8, trimesh, manifold3d, shapely)
         --zip-only repackages WORK (assembly STEP + checks.json) without rebuilding
